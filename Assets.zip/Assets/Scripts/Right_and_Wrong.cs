﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Right_and_Wrong : MonoBehaviour
{
    public void Right1()
    {
     Debug.Log("Right!");
         SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void Wrong()
    {
         Debug.Log("Wrong!");
         SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);   
    }
}

