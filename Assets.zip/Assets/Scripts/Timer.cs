﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;



public class Timer : MonoBehaviour
{
	public GameObject textDisplay;

	public int secondsLeft = 30;

	public bool takingaway = false;

	void Start()
	{
		textDisplay.GetComponent<Text>().text = "00:" + secondsLeft;


	}


	void Update()
	{
		if (takingaway == false && secondsLeft > 0)
		{
			StartCoroutine(TimerTake());
		}
		if (secondsLeft <= 0)
		{
           SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
		}
	}
   



	IEnumerator TimerTake()
	{
		takingaway = true;

		yield return new WaitForSeconds(1);

		secondsLeft -= 1;

		textDisplay.GetComponent<Text>().text = "00:" + secondsLeft;

		takingaway = false;

	}
}
