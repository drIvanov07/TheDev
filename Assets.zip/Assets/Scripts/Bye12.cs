﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Bye12 : MonoBehaviour
{
    public void Quit3()
    {
        Application.Quit();
    }
}
