﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Bye : MonoBehaviour
{
    public void Quit3()
    {
        Application.Quit();
    }
}
